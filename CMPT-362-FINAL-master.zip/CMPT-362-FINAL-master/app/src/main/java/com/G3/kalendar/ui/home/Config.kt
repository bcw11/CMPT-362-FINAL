package com.G3.kalendar.ui.home

object Config {
    val EMAIL = "KalendarRecoveryTeam@gmail.com"
    val PASSWORD = "nxiyzpmdxcgttcjo"
}